LOKVENDRA KNOWLEDGE SERIES — LOCAL WEBSITE PROTOTYPE
=====================================================

Included:
- index.html: bilingual Hindi + English, self-contained local prototype.

TEST LOCALLY
1. Download and extract this ZIP.
2. Open index.html in a modern browser (Chrome, Edge, Firefox).
3. Navigate through Home, Tests, Study Library, PDF Store, Score History, Student Login, and Admin Panel.
4. Test an MCQ set and submit to see score/explanations.
5. Add sample study resources or products from Admin Panel. Local data uses browser localStorage.

ANDROID
- Extract ZIP using a file manager and open index.html in a browser if supported.
- If local HTML files are blocked by the phone/browser, test on a computer or publish a preview to static hosting.

IMPORTANT LIMITATIONS
- This is a front-end local prototype, not a production-ready service.
- Demo login is NOT secure authentication; no password is validated.
- Score history and demo-added content are saved in the current browser only; they are not synced across devices/users.
- Admin panel has no authorization. Never publish it as-is.
- Store checkout is a demo and does not collect money.
- Real student accounts, roles, secure admin, database-backed score history, file uploads, payments, refunds/invoices, and protected paid PDF downloads require a backend/database and payment gateway.
- Never store payment secrets or trust a client-side payment success flag. Verify payments server-side.
- Only distribute PDFs you own or are authorized to sell.

PUBLISH A PREVIEW (STATIC FRONTEND ONLY)
Option A — GitHub Pages:
1. Sign in to GitHub and create a repository.
2. Upload index.html to the repository root.
3. Open Settings → Pages.
4. Choose deployment from the main branch and root folder, then save.
5. Use the public URL GitHub Pages provides.

Option B — Netlify / similar static hosting:
1. Sign in to a static hosting provider.
2. Upload the folder containing index.html or connect the repository.
3. Follow its deploy instructions and open the preview URL.

Before launching real users or selling PDFs:
1. Build a backend/API and database (for example, a suitable managed database).
2. Implement proper authentication, password hashing, account recovery, and admin roles.
3. Store files in private/object storage and issue time-limited download URLs after verified payment.
4. Integrate a payment gateway supported in India; verify payment signatures on the server.
5. Add privacy policy, terms, refund policy, contact details, backups, HTTPS, and security testing.
6. Test on mobile and desktop before launch.
